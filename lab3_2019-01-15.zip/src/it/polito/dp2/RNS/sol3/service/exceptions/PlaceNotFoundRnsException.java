package it.polito.dp2.RNS.sol3.service.exceptions;

public class PlaceNotFoundRnsException extends NotFoundRnsException{

	public PlaceNotFoundRnsException(String message) {
		super(message);
	}

	public PlaceNotFoundRnsException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
