package it.polito.dp2.RNS.sol3.service.exceptions;

public class VehicleNotFoundRnsException extends NotFoundRnsException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehicleNotFoundRnsException(String message) {
		super(message);
	}

	public VehicleNotFoundRnsException() {
		// TODO Auto-generated constructor stub
	}
}
