package it.polito.dp2.RNS.sol3.service.exceptions;

public class RoadNotFoundRnsException extends NotFoundRnsException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RoadNotFoundRnsException(String message) {
		super(message);
	}

	public RoadNotFoundRnsException() {
		// TODO Auto-generated constructor stub
	}
}

